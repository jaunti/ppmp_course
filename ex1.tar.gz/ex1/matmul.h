#pragma once

void print_cuda_devices();
void matmul();